def findWaitingTime(processes, n, bt, at, wt, quantum):
    # Remaining burst time
    rem_bt = [bt[i] for i in range(n)]
    t = 0  # Current time

    # Looping until all processes are completed
    while True:
        done = True
        for i in range(n):
            # If burst time > 0, process it
            if rem_bt[i] > 0:
                done = False
                if rem_bt[i] > quantum and at[i] <= t:
                    t += quantum
                    rem_bt[i] -= quantum
                elif at[i] <= t:
                    t += rem_bt[i]
                    wt[i] = t - bt[i] - at[i]
                    rem_bt[i] = 0

        if done:
            break


def findTurnAroundTime(processes, n, bt, at, wt, tat):
    # Calculating Turnaround Time
    for i in range(n):
        tat[i] = bt[i] + wt[i]


def roundRobin(processes, bt, at, quantum):
    n = len(processes)
    wt = [0] * n  # Waiting times
    tat = [0] * n  # Turnaround times

    # Find waiting and turnaround times
    findWaitingTime(processes, n, bt, at, wt, quantum)
    findTurnAroundTime(processes, n, bt, at, wt, tat)

    # Calculate averages
    avg_wt = sum(wt) / n
    avg_tat = sum(tat) / n

    # Display process details
    print("This the Round Robin Scheduling Algorithm")
    print("\nProcess\tBurst Time\tArrival Time\tWaiting Time\tTurnaround Time")
    for i in range(n):
        print(f"{processes[i]}\t{bt[i]}\t\t{at[i]}\t\t{wt[i]}\t\t{tat[i]}")

    print(f"\nAverage Waiting Time: {avg_wt:.2f} ms")
    print(f"Average Turnaround Time: {avg_tat:.2f} ms")

    return wt, tat


def ganttChart(processes, bt, at, quantum):
    rem_bt = [bt[i] for i in range(len(bt))]
    time = 0
    gantt = []
    queue = []

    while any(rem_bt):
        for i in range(len(at)):
            if at[i] <= time and rem_bt[i] > 0 and i not in queue:
                queue.append(i)

        if not queue:
            gantt.append("Idle")
            time += 1
            continue

        current = queue.pop(0)
        gantt.append(processes[current])

        if rem_bt[current] > quantum:
            time += quantum
            rem_bt[current] -= quantum
        else:
            time += rem_bt[current]
            rem_bt[current] = 0

    print("\nGantt Chart:")
    print(" -> ".join(gantt))


# Main function to input details and run the algorithm
def main():
    n = int(input("Enter the number of processes: "))
    processes = []
    bt = []
    at = []

    for i in range(n):
        processes.append(input(f"Enter Process ID for process {i + 1}: "))
        bt.append(int(input(f"Enter Burst Time for {processes[-1]} (ms): ")))
        at.append(int(input(f"Enter Arrival Time for {processes[-1]} (ms): ")))

    quantum = int(input("Enter Time Quantum (ms): "))

    print("\nSimulating Round Robin Scheduling...")
    roundRobin(processes, bt, at, quantum)
    ganttChart(processes, bt, at, quantum)


if __name__ == "__main__":
    main()
