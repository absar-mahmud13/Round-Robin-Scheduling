import pandas as pd

def round_robin_scheduling():
    # Input the number of processes
    n = int(input("Enter the number of processes: "))

    # Input process details
    processes = []
    burst_time = []
    arrival_time = []

    for i in range(n):
        pid = input(f"Enter Process ID for process {i+1}: ")
        bt = int(input(f"Enter Burst Time for {pid} (ms): "))
        at = int(input(f"Enter Arrival Time for {pid} (ms): "))
        processes.append(pid)
        burst_time.append(bt)
        arrival_time.append(at)

    # Input the time quantum
    time_quantum = int(input("Enter Time Quantum (ms): "))

    # Initialize variables
    remaining_bt = burst_time[:]
    completion_time = [0] * n
    gantt_chart = []
    time = 0
    queue = []

    # Process queue simulation
    while any(remaining_bt):
        for i in range(n):
            if arrival_time[i] <= time and remaining_bt[i] > 0 and i not in queue:
                queue.append(i)

        if not queue:
            gantt_chart.append("Idle")
            time += 1
            continue

        current = queue.pop(0)
        gantt_chart.append(processes[current])

        # Execute current process
        if remaining_bt[current] > time_quantum:
            time += time_quantum
            remaining_bt[current] -= time_quantum
        else:
            time += remaining_bt[current]
            remaining_bt[current] = 0
            completion_time[current] = time

        # Add processes to the queue based on arrival time
        for i in range(n):
            if arrival_time[i] <= time and remaining_bt[i] > 0 and i not in queue:
                queue.append(i)

    # Calculate Turnaround Time (TAT) and Waiting Time (WT)
    turnaround_time = [completion_time[i] - arrival_time[i] for i in range(n)]
    waiting_time = [turnaround_time[i] - burst_time[i] for i in range(n)]

    # Calculate averages
    average_tat = sum(turnaround_time) / n
    average_wt = sum(waiting_time) / n

    # Display results
    data = {
        "Process": processes,
        "Burst Time": burst_time,
        "Arrival Time": arrival_time,
        "Completion Time": completion_time,
        "Turnaround Time": turnaround_time,
        "Waiting Time": waiting_time,
    }
    df = pd.DataFrame(data)
    print("\nProcess Scheduling Table:")
    print(df)
    print(f"\nAverage Turnaround Time: {average_tat:.2f} ms")
    print(f"Average Waiting Time: {average_wt:.2f} ms")

    # Display Gantt Chart
    gantt_display = " | ".join(gantt_chart)
    print(f"\nGantt Chart:\n{gantt_display}")

# Run the scheduler
round_robin_scheduling()
